document.getElementsByTagName('body')[0].onscroll = (e) => {
  const inner = document.querySelector('.inner_detail')      
  if( e.target.scrollTop == 0 ) {        
    {% if product.options contains 'Kits' %}
      inner.style.top = '-400px'
    {% else %}
      inner.style.top = '-110px'
    {% endif %}
  }
};