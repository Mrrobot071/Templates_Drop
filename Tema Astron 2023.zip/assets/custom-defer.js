$(function() {

  /* ----------> image with thumbnail slider <---------- */

  if($('body').find('.trending_container'). length > 0) {
    $('.trending_text_items').slick({
      slidesToShow: 1,
      slidesToScroll: 1,
      arrows: false,
      infinite: true,
      speed: 500,
      fade: !0,
      cssEase: 'linear',
      asNavFor: '.trending_img_items'
    });

    $('.trending_img_items').slick({
      slidesToShow: 1,
      slidesToScroll: 1,
      asNavFor: '.trending_text_items',
      dots: false,
      autoplay: true,
      autoplaySpeed: 3000,
      speed: 800,
      arrows: true,
      infinite: true
    });
  }

  /* ----------> Simple slick slider start <---------- */

  if($('body').find(".item_slider").length > 0){
    $('.item_slider').each(function() {
      var $sliderID =  $(this).attr('id');
      $("#"+$sliderID).slick();
    });
  }

  /* ----------> Simple slick slider end <---------- */

  /* ----------> Center mode slick slider start <---------- */

  if($('body').find(".center_item_slider").length > 0){
    $('.center_item_slider').each(function() {
      var $sliderID =  $(this).attr('id');
      $("#"+$sliderID).slick({
        centerMode: true,
        centerPadding: '250px'
      });
    });
  }

  /* ----------> Center mode slick slider end <---------- */

  /* ----------> Currency switcher <---------- */

  $('.currency_switcher form .disclosure__toggle').click(function() {
    $(this).next('.disclosure-list').toggleClass('active');
  });

  /* ----------> Color swatch on mouse hover <---------- */

  $("body").delegate(".color-swatch", "mouseover", function() {
    var $orgimg = $(this).attr("data-pro-org-img");
    var $proid = $(this).attr("data-color-pro-id");
    $(".image-"+$proid).attr("srcset",$orgimg);
  });

  $('.swatch_item span').each(function() {
    var lazy = $(this);
    var src = lazy.attr('data-bg');
    lazy.css('background-image', 'url("'+src+'")');
  });

  /* ----------> Language translation and swticher <---------- */

  $('.language_switcher_selected').on("click",function() {
    $(this).next("ul").slideToggle();
  });

  $('body').on("mouseup",function(e) {
    var container = $("#translation");
    // if the target of the click isn't the container nor a descendant of the container
    if (!container.is(e.target) && container.has(e.target).length === 0)
    {
      container.hide();
    }
  });

  $('#translation li').on("click",function() {
    var lang = $(this).attr('class');
    var $frame = $('.goog-te-menu-frame:first');
    if (!$frame.length) {
      alert("Error: Could not find Google translate frame.");
      return false;
    }
    $frame.contents().find('.goog-te-menu2-item span.text:contains('+lang+')').get(0).click();
    $("#translation").slideUp();
    return false;
  });

  setInterval(function(){
    var checkarabic =  $("html").attr("lang");
    if(checkarabic == "ar"){
      if($('body').hasClass('rtl')){
      }else{
        $("body").addClass("rtl");
      }
    }else{
      $("body").removeClass("rtl");
    }
    if($(".language_switcher_selected").find("img").length == 0){
      var htmllan =  $("html").attr("lang");
      $('#translation li').each(function(){
        if($(this).find("img").attr("alt") == htmllan){
          $(".language_switcher_selected").html($(this).html());
        }
      })
    }else{
      if($(".language_switcher_selected").find("img").attr("alt") != $("html").attr("lang")){
        $('#translation li').each(function(){
          if($(this).find("img").attr("alt") == $("html").attr("lang")){
            $(".language_switcher_selected").html($(this).html());
          }
        })
      }
    }
  },10);

  /* ----------> Scroll back to top script  <---------- */

  var btn = $('.backtotop');
  $(window).scroll(function() {
    if ($(window).scrollTop() > 800) {
      btn.addClass('show');
    } else {
      btn.removeClass('show');
    }
  });
  btn.on('click', function(e) {
    e.preventDefault();
    $('html, body').animate({scrollTop:0}, '300');
  });

  /* ----------> Footer responsive script <---------- */

  if ( $(window).width() < 990 ) {
    $('.site-footer__content .site-footer__item .site-footer__item-inner .h4').click(function (){
      if($(this).parent().hasClass('active')) {
        $(this).parent().removeClass('active');
        $(this).next(".site-footer__linklist").slideUp();
      } else {
        $('.site-footer__content .site-footer__item .site-footer__item-inner').removeClass('active');
        $(this).parent().addClass('active');
        $(".site-footer__content .site-footer__item .site-footer__item-inner .site-footer__linklist").slideUp();
        //$(".site-footer__content .site-footer__item .site-footer__item-inner--text .site-footer__rte").slideUp();
        $(this).parent(".site-footer__item-inner").find(".site-footer__linklist").slideDown();
      }
    });
  }

  /* ----------> Minicart start <---------- */

  function addToCartSuccess() {
    $.get( "/cart?view=mini", function( data ) {
      $('#crt').html(data);
      $('#crt').removeClass('loading');
    });
  }
  function refreshCart(cart) {
    $('.cart-count').text(cart.item_count);
  }

  $('body').on('click','.buttonAddtoCart',function(e){
    //e.preventDefault();
    var btn = $(this);
    var form = $(this).closest('form');
    btn.attr('disabled', 'disabled');
    btn.text('adicionando...');
    form.find('.error').remove();

    $.ajax({
      type: 'POST',
      url: '/cart/add.js',
      data: form.serialize(),
      dataType: 'json',
      error: function(jqXHR, textStatus, errorThrown){
        var response = $.parseJSON(jqXHR.responseText);
        form.append('<p class="error">'+response.description+'</p>').find('.error').fadeIn().delay(4000).fadeOut();
        btn.text('adicionar ao carrinho');
        btn.removeAttr('disabled');
      }
    }).done(function( data ) {
      addToCartSuccess();
      btn.text('adicionar ao carrinho');
      btn.removeAttr('disabled');
      $.getJSON('/cart.js', function(cart){
        refreshCart(cart);
      });
      setTimeout(function(){
        $('body').addClass('cartOpen');
        $('.fullPage').addClass('witmenu');
      },1000);
      $('.productGrid .productItem').removeClass('qvopen');
      $('.close-cart-body').addClass("active");
    });
  });
  $('body').on('click','.fullPage.witmenu, .closemenu, .closecart', function(e){
    //e.preventDefault();
    $('body').removeClass('menuOpen');
    $('.fullPage').removeClass('witmenu');
    $('body').removeClass('cartOpen');
    $('.close-cart-body').removeClass("active");
  });
  $('.cart_button').on('click',function(e){
    //e.preventDefault();
    setTimeout(function(){
      $('body').addClass('cartOpen1');
      $('.fullPage').addClass('witmenu');
      $('.close-cart-body').addClass("active");
    }, 50);
  });
  $('body').on('click', '.adjust',function(){
    var input = $(this).parent().find('input');
    var ip = parseInt(input.val());
    if($(this).hasClass('plus')) {
      ip = ip + 1;
    } else {
      ip = ip - 1;
    }

    if(ip==0) {
      //return false;
    }
    input.val(ip);

    $('#crt').addClass('loading');
    var id = parseInt(input.attr('data-id'));
    $.ajax({
      type: 'POST',
      url: '/cart/update.js',
      data: 'updates['+id+']='+ip,
      dataType: 'json',
      error: function(jqXHR, textStatus, errorThrown){
        var response = $.parseJSON(jqXHR.responseText);
        alert(response.description);
        $('#crt').removeClass('loading');
      }
    }).done(function( data ) {
      addToCartSuccess();
      $.getJSON("/cart.js", function(cart) {
        refreshCart(cart);
      });
      $('#crt').removeClass('loading');
    });
  });
  $("#crt").on('click', "a.remove_item", function(r){
    $('#crt').addClass('loading');
    //r.preventDefault();
    var id = $(this).data("id");
    Shopify.changeItem(id,0, function(c){
      $('.itemCount').text(c.item_count);
      if(!c.item_count) {
        $('#crt').empty();
        $('#crt').append('<div class="empty_cart"><img class="lazyload" data-src="//cdn.shopify.com/s/files/1/0287/7698/8809/t/47/assets/minicart_close.png?v=70364635169611651451627101714" alt="" /><p class="emptyCart text-center">Seu carrinho está vazio.</p><a href="/" class="closecart btn emptyClose">Voltar para a loja</a></div>');
                         $('#crt').removeClass('has-item');
        $('#crt').removeClass('loading');
        $.getJSON("/cart.js", function(cart) {
          refreshCart(cart);
        });
      } else {
        addToCartSuccess();
      }
    });
    $.getJSON("/cart.js", function(cart) {
      refreshCart(cart);
    });
  });

  $("body").delegate(".mini_cart_tool .cart_note", "click", function() {
    $('.cart-note').addClass('active');
    $('.mini_cart_tool').hide(slow);
  });
  $("body").delegate(".cart-note .close-note", "click", function() {
    $('.cart-note').removeClass('active');
    $('.mini_cart_tool').show(slow);
  });
  $("body").delegate(".mini_cart_tool .cart_shipping", "click", function() {
    $('.minicart_calculator').addClass('active');
  });
  $("body").delegate(".minicart_calculator .close-calculator", "click", function() {
    $('.minicart_calculator').removeClass('active');
  });

  /* ----------> Minicart end <---------- */

  /* ----------> Animation js start <---------- */

  $(function() {
    var doAnimations = function() {
      // Calc current offset and get all animatables
      var offset = $(window).scrollTop() + $(window).height(),
          $animatables = $('.animatable');
      // Unbind scroll handler if we have no animatables
      if ($animatables.length == 0) {
        $(window).off('scroll', doAnimations);
      }
      // Check all animatables and animate them if necessary
      $animatables.each(function(i) {
        var $animatable = $(this);
        if (($animatable.offset().top + $animatable.height() - 20) < offset) {
          $animatable.removeClass('animatable').addClass('animated');
        }
      });
    };
    // Hook doAnimations on scroll, and trigger a scroll
    $(window).on('scroll', doAnimations);
    $(window).trigger('scroll');
  });

  /* ----------> Animation js end <---------- */








});
